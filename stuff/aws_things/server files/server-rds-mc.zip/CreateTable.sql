create database myDBName;
grant all on myDBName.* to 'master' identified by 'password';
use myDBName;
CREATE TABLE mytable (id VARCHAR(100),hash VARCHAR(200));