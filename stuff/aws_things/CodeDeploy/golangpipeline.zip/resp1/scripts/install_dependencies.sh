#!/bin/bash
cd /home/ec2-user
fuser -k 80/tcp
rm -rf *
